package j01_basic;

public class Hello01 {

	public static void main(String[] args) {
		System.out.println("*** 안녕 하세요 !!! ***");
		System.out.print("저는 강사 엄미현 입니다.\n");
		System.out.println("저는 20살이고 키는 170cm 입니다.");
		System.out.println("하하하 ~~~ 보시다시피 거짓말 입니다.");
	} //main

} //class
