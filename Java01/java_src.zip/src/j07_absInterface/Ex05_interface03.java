package j07_absInterface;

public class Ex05_interface03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
