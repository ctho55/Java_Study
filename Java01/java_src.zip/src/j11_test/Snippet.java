package j11_test;

public class Snippet {
	public static void main(String[] args) {
				ty.stop=true;
	}
}

