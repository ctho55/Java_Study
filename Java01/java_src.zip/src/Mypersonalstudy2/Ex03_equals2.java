package Mypersonalstudy2;

public class Ex03_equals2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
